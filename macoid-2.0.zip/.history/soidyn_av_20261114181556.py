#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Soidyn AV - renderer binaural gaya Atmos, full Python.

  Soidyn Driver (7.1.4 / 7.1 / 5.1 / stereo)
      -> upmix ke 7.1.4 (numba)
      -> ENGINE "HRIR"  : HRTF hasil ukur dari file .sofa (sofar) + FIR numba nogil + room FDN  [terbaik]
         ENGINE "FAST"  : model kepala numba (tanpa file, paling ringan)
         ENGINE "SPARTA": plugin SPARTA Binauraliser lewat pedalboard (eksperimen, auto-fallback)
         ENGINE "AV"    : Apple AVAudioEngine HRTFHQ (berat, untuk Mac baru)
         Kalau engine gagal dimuat -> otomatis turun HRIR -> FAST.
      -> LFE + master + limiter (pedalboard)
      -> Built-In Output

Install : pip3 install numpy numba sounddevice pedalboard scipy sofar
          (ENGINE "AV" juga butuh: pip3 install pyobjc-framework-AVFoundation)
Jalankan: python3 soidyn_av.py        (semua pengaturan = konstanta di bawah, tanpa command)
Pakai headphone di jack Built-In. Binaural tidak cocok untuk speaker laptop.
Run pertama numba compile sekitar beberapa detik, setelahnya di-cache (cache=True).
"""
import gc
import sys
import threading
import time

import numpy as np
import sounddevice as sd

try:
    from numba import njit
    HAS_NUMBA = True
except Exception:  # numba tidak ada -> jalan lambat tanpa JIT
    HAS_NUMBA = False

    def njit(*a, **k):
        if len(a) == 1 and callable(a[0]) and not k:
            return a[0]
        return lambda f: f

# ============================================================ PENGATURAN (konstanta)
INPUT_DEVICE_NAME = "Soidyn Driver"
OUTPUT_DEVICE_CANDIDATES = ("Built-in Output", "MacBook Pro Speakers", "MacBook Air Speakers",
                            "External Headphones", "Headphones", "Speakers")
SAMPLE_RATE = 48000
INPUT_CHANNELS = None          # None = otomatis (maks 12). Isi angka kalau mau dipaksa.
INPUT_CHANNEL_MAP = None       # reorder kanal input, mis. [0,1,2,3,4,5,6,7,8,9,10,11]
PA_BLOCK = 512                 # blok PortAudio (10.7 ms)
BLOCK = 512                    # frame per render AV (10.7 ms). Kalau masih patah, coba 1024
OUT_TARGET_BLOCKS = 4          # buffer output awal (4 x 10.7 ms)
MAX_TARGET_BLOCKS = 12         # batas atas: tiap underrun buffer otomatis +1 blok sampai batas ini (anti-patah adaptif)
PA_LATENCY = 0.04              # detik, latency device PortAudio (lebih besar = lebih aman di Mac lama)

ENGINE = "HRIR"                # "HRIR" | "FAST" | "SPARTA" | "AV"   (gagal -> fallback otomatis ke FAST)
SOFA_NAME = "KEMAR_s.sofa"     # cukup NAMA file. Dicari otomatis di folder script, folder kerja, Downloads, Desktop, Documents, home
                               # None = pakai *.sofa pertama yang ketemu di folder script
SOFA_SWAP_EARS = False         # True kalau kiri-kanan terasa terbalik dengan file .sofa-mu
HRIR_TAPS = 256                # panjang FIR per telinga (128 = lebih ringan, 256 = lebih tajam)
SPARTA_NAME = "sparta_binauraliser"   # cukup nama plugin (.vst3 / .component), dicari di folder Plug-Ins sistem & user
BOOSTER = 159.0                # volume booster (x159 = +44 dB), dikali sebelum limiter
SOFT_START_SEC = 1.5           # naik pelan dari 0 -> penuh supaya tidak "meledak" di awal

# --- rasa Atmos (ENGINE FAST) ---
FRONT_AZ = 35.0                # sudut speaker L/R depan (derajat). Lebih lebar = panggung lebih luas
ITD_SCALE = 1.25               # 1.0 = kepala normal. Naikkan = lebih "keluar kepala"
SHADOW = 1.2                   # kekuatan head shadow / ILD
BINAURAL_GAIN = 0.7
ROOM_MIX = 0.5                 # ruang: 0 = kering. 0.5 = seimbang (~-10 dB di bawah suara langsung). 1.0 = basah (~-4 dB)
ROOM_TAIL = 0.0                # 0 = TANPA ekor (hanya pantulan awal <30 ms). 1.0 = ekor reverb penuh
ROOM_RT60 = 0.45               # detik, panjang ekor (hanya dipakai kalau ROOM_TAIL > 0)
ROOM_PREDELAY_MS = 14.0        # jeda sebelum ekor muncul -> detail suara langsung tetap jelas
ROOM_EARLY = 1.0               # level pantulan awal (memberi "badan"/ruang tanpa ekor)
ER_CAL = 0.87                  # kalibrasi internal (jangan diubah; atur lewat ROOM_MIX)
ROOM_BRIGHT_HZ = 7000.0        # peredam ekor; lebih tinggi = ruang lebih cerah/detail
ROOM_LOWCUT_HZ = 180.0         # buang bass dari kiriman reverb supaya tidak keruh
ROOM_SEND = 0.46               # kalibrasi internal (jangan diubah; atur lewat ROOM_MIX)

# --- upmix stereo -> 7.1.4 ---
WIDTH = 1.4                    # penguat sinyal samping (S) sebelum jadi surround/tinggi
SURROUND_GAIN = 1.5
HEIGHT_GAIN = 1.6

SPEAKER_DISTANCE = 1.5         # meter, jarak 11 speaker virtual dari kepala
RENDERING = "HRTFHQ"           # HRTFHQ | HRTF | SphericalHead | EqualPowerPanning  (kalau CPU berat: "HRTF")
REVERB_BLEND = 0.25            # (ENGINE AV) 0 = kering. 0.1-0.3 = ada nuansa ruang
INPUT_GAIN = 1.0
MASTER_GAIN = 1.0              # master tambahan (dikali BOOSTER)
LFE_GAIN = 0.7
LIMITER_THRESHOLD_DB = -1.0
LIMITER_RELEASE_MS = 120.0

# ============================================================ layout 7.1.4 (urutan = Soidyn Driver / Atmos)
# L R C LFE Ls Rs Lrs Rrs Ltf Rtf Ltr Rtr  -> (azimuth derajat, + = kiri ; elevasi derajat)
LAYOUT = [(FRONT_AZ, 0), (-FRONT_AZ, 0), (0, 0), (0, 0), (90, 0), (-90, 0), (150, 0), (-150, 0),
          (45, 45), (-45, 45), (135, 45), (-135, 45)]
LFE_INDEX = 3
PLAYER_IDX = [i for i in range(12) if i != LFE_INDEX]


def az_el_to_xyz(az_deg, el_deg, d):
    """AVAudio3DPoint: +x kanan, +y atas, +z ke belakang (pendengar menghadap -z)."""
    az, el = np.radians(az_deg), np.radians(el_deg)
    return (float(-np.sin(az) * np.cos(el) * d), float(np.sin(el) * d), float(-np.cos(az) * np.cos(el) * d))


# ============================================================ kernel numba
@njit(cache=True, fastmath=True, nogil=True)
def _hp_kernel(x, a, st):
    """One-pole highpass: y[n] = a*(x[n]-x[n-1]) + a*y[n-1]. st = [x_prev, y_prev]."""
    n = x.shape[0]
    y = np.empty(n, np.float32)
    xp = st[0]
    yp = st[1]
    for i in range(n):
        xi = x[i]
        yi = a * (xi - xp) + a * yp
        y[i] = yi
        xp = xi
        yp = yi
    st[0] = xp
    st[1] = yp
    return y


@njit(cache=True, fastmath=True, nogil=True)
def _mix_kernel(x, out, S, ch):
    """x (n, ch) -> out (12, n) bed + S (sinyal samping untuk turunan tinggi/surround)."""
    n = x.shape[0]
    for i in range(n):
        if ch <= 2:
            L = x[i, 0]
            if ch > 1:
                R = x[i, 1]
            else:
                R = L
            M = 0.5 * (L + R)
            S[i] = 0.5 * (L - R)
            out[0, i] = L - 0.2 * M
            out[1, i] = R - 0.2 * M
            out[2, i] = 0.35 * M
        else:
            m = ch if ch < 8 else 8
            for c in range(m):
                out[c, i] = x[i, c]
            L = x[i, 0]
            R = x[i, 1]
            Ls = x[i, 4] if ch > 4 else 0.0
            Rs = x[i, 5] if ch > 5 else 0.0
            Lrs = x[i, 6] if ch >= 8 else 0.0
            Rrs = x[i, 7] if ch >= 8 else 0.0
            S[i] = 0.5 * ((L + Ls + Lrs) - (R + Rs + Rrs))


@njit(cache=True, fastmath=True, nogil=True)
def _derive_kernel(out, full, base, n, stereo, d8, d12, d18, d22, sg, hg):
    """Isi kanal tinggi (dan surround untuk stereo) dari delay line sinyal samping."""
    for i in range(n):
        out[8, i] = 0.30 * hg * full[base - d8 + i]
        out[9, i] = -0.30 * hg * full[base - d8 + i]
        out[10, i] = 0.25 * hg * full[base - d18 + i]
        out[11, i] = -0.25 * hg * full[base - d18 + i]
        if stereo:
            out[4, i] = 0.5 * sg * full[base - d12 + i]
            out[5, i] = -0.5 * sg * full[base - d12 + i]
            out[6, i] = 0.35 * sg * full[base - d22 + i]
            out[7, i] = -0.35 * sg * full[base - d22 + i]


@njit(cache=True, fastmath=True, nogil=True)
def _stretch_kernel(y, m):
    """(2, n) -> (2, m) interpolasi linear, koreksi drift clock +-1 sampel per blok."""
    c = y.shape[0]
    n = y.shape[1]
    out = np.empty((c, m), np.float32)
    scale = (n - 1) / (m - 1) if m > 1 else 0.0
    for ch in range(c):
        for j in range(m):
            p = j * scale
            i0 = int(p)
            if i0 >= n - 1:
                out[ch, j] = y[ch, n - 1]
            else:
                f = p - i0
                out[ch, j] = y[ch, i0] * (1.0 - f) + y[ch, i0 + 1] * f
    return out


@njit(cache=True, fastmath=True, nogil=True)
def _tanh_kernel(y):
    out = np.empty_like(y)
    f = y.reshape(-1)
    o = out.reshape(-1)
    for i in range(f.shape[0]):
        o[i] = np.tanh(f[i])
    return out


@njit(cache=True, fastmath=True, nogil=True)
def _binaural_kernel(feeds, hist, ext, lp2, lpL, lpR, dL, dR, gL, gR, aL, aR, a2, hg, out):
    """11 speaker virtual -> 2 telinga. Per sumber: pinna (split 5k) -> delay ITD -> head shadow lowpass -> gain."""
    S = feeds.shape[0]
    N = feeds.shape[1]
    H = hist.shape[1]
    for s in range(S):
        for j in range(H):
            ext[j] = hist[s, j]
        l2 = lp2[s]
        c2 = a2[s]
        h = hg[s]
        for k in range(N):
            x = feeds[s, k]
            l2 = c2 * l2 + (1.0 - c2) * x
            ext[H + k] = l2 + h * (x - l2)
        lp2[s] = l2
        diL = int(dL[s])
        frL = dL[s] - diL
        diR = int(dR[s])
        frR = dR[s] - diR
        yl = lpL[s]
        yr = lpR[s]
        cl = aL[s]
        cr = aR[s]
        gl = gL[s]
        gr = gR[s]
        for k in range(N):
            vl = ext[H + k - diL] * (1.0 - frL) + ext[H + k - diL - 1] * frL
            vr = ext[H + k - diR] * (1.0 - frR) + ext[H + k - diR - 1] * frR
            yl = cl * yl + (1.0 - cl) * vl
            yr = cr * yr + (1.0 - cr) * vr
            out[0, k] += gl * yl
            out[1, k] += gr * yr
        lpL[s] = yl
        lpR[s] = yr
        for j in range(H):
            hist[s, j] = ext[N + j]


@njit(cache=True, fastmath=True, nogil=True)
def _early_kernel(sL, sR, hist, ext, dL, gL, srcL, dR, gR, srcR, pre, er, prd):
    """Pantulan awal (multi-tap) + pre-delay untuk input FDN."""
    N = sL.shape[0]
    H = hist.shape[1]
    for j in range(H):
        ext[0, j] = hist[0, j]
        ext[1, j] = hist[1, j]
    for k in range(N):
        ext[0, H + k] = sL[k]
        ext[1, H + k] = sR[k]
    for k in range(N):
        aL = 0.0
        for i in range(dL.shape[0]):
            aL += gL[i] * ext[srcL[i], H + k - dL[i]]
        aR = 0.0
        for i in range(dR.shape[0]):
            aR += gR[i] * ext[srcR[i], H + k - dR[i]]
        er[0, k] = aL
        er[1, k] = aR
        prd[0, k] = ext[0, H + k - pre]
        prd[1, k] = ext[1, H + k - pre]
    for j in range(H):
        hist[0, j] = ext[0, N + j]
        hist[1, j] = ext[1, N + j]


@njit(cache=True, fastmath=True, nogil=True)
def _fdn_kernel(sL, sR, bufs, idx, lens, g, dstate, da, out):
    """FDN 4 line (Hadamard) untuk ruang. Input sL/sR, output out (2, n)."""
    n = sL.shape[0]
    for k in range(n):
        v0 = bufs[0, idx[0]]
        v1 = bufs[1, idx[1]]
        v2 = bufs[2, idx[2]]
        v3 = bufs[3, idx[3]]
        dstate[0] = da * dstate[0] + (1.0 - da) * v0
        dstate[1] = da * dstate[1] + (1.0 - da) * v1
        dstate[2] = da * dstate[2] + (1.0 - da) * v2
        dstate[3] = da * dstate[3] + (1.0 - da) * v3
        v0 = dstate[0] * g[0]
        v1 = dstate[1] * g[1]
        v2 = dstate[2] * g[2]
        v3 = dstate[3] * g[3]
        m0 = 0.5 * (v0 + v1 + v2 + v3)
        m1 = 0.5 * (v0 - v1 + v2 - v3)
        m2 = 0.5 * (v0 + v1 - v2 - v3)
        m3 = 0.5 * (v0 - v1 - v2 + v3)
        l = sL[k]
        r = sR[k]
        bufs[0, idx[0]] = m0 + l
        bufs[1, idx[1]] = m1 + r
        bufs[2, idx[2]] = m2 - l
        bufs[3, idx[3]] = m3 - r
        for j in range(4):
            idx[j] += 1
            if idx[j] >= lens[j]:
                idx[j] = 0
        out[0, k] = 0.5 * (v0 + v2)
        out[1, k] = 0.5 * (v1 + v3)


@njit(cache=True, fastmath=True, nogil=True)
def _fir_kernel(feeds, hist, ext, hr, out):
    """FIR langsung 11 sumber -> 2 telinga. hr (S, 2, T) sudah dibalik (hr[..,t] = h[T-1-t])."""
    S = feeds.shape[0]
    N = feeds.shape[1]
    T = hr.shape[2]
    H = T - 1
    for s in range(S):
        for j in range(H):
            ext[j] = hist[s, j]
        for k in range(N):
            ext[H + k] = feeds[s, k]
        for ear in range(2):
            for k in range(N):
                acc = 0.0
                for t in range(T):
                    acc += hr[s, ear, t] * ext[k + t]
                out[ear, k] += acc
        for j in range(H):
            hist[s, j] = ext[N + j]


def warmup():
    """Compile semua kernel sebelum audio jalan supaya tidak ada glitch di blok pertama."""
    x = np.zeros((BLOCK, 2), np.float32)
    out = np.zeros((12, BLOCK), np.float32)
    S = np.zeros(BLOCK, np.float32)
    st = np.zeros(2, np.float64)
    _hp_kernel(S, 0.97, st)
    _mix_kernel(x, out, S, 2)
    _mix_kernel(np.zeros((BLOCK, 8), np.float32), out, S, 8)
    full = np.zeros(BLOCK * 4, np.float32)
    _derive_kernel(out, full, BLOCK * 2, BLOCK, True, 10, 20, 30, 40, 1.0, 1.0)
    y = np.zeros((2, BLOCK), np.float32)
    _stretch_kernel(y, BLOCK - 1)
    _stretch_kernel(y, BLOCK + 1)
    _tanh_kernel(y)
    FastSpatial().render(np.zeros((len(PLAYER_IDX), BLOCK), np.float32))
    limit(np.zeros((2, BLOCK), np.float32))
    _fir_kernel(np.zeros((2, BLOCK), np.float32), np.zeros((2, 15), np.float32),
                np.zeros(15 + BLOCK, np.float32), np.zeros((2, 2, 16), np.float32), np.zeros((2, BLOCK), np.float32))


# ============================================================ upmixer
class Upmixer:
    """Input (n, ch) -> (12, n) urutan 7.1.4. Tinggi/surround diturunkan dari sinyal samping."""

    def __init__(self):
        self.hist = np.zeros(int(SAMPLE_RATE * 0.03), np.float32)
        self.a = float(np.exp(-2 * np.pi * 250.0 / SAMPLE_RATE))
        self.st = np.zeros(2, np.float64)
        ms = lambda t: int(SAMPLE_RATE * t / 1000.0)
        self.d8, self.d12, self.d18, self.d22 = ms(8), ms(12), ms(18), ms(22)

    def process(self, x):
        if INPUT_CHANNEL_MAP:
            x = x[:, INPUT_CHANNEL_MAP]
        x = np.ascontiguousarray(x, dtype=np.float32)
        n, ch = x.shape
        out = np.zeros((12, n), np.float32)
        if ch >= 12:                       # sudah 7.1.4
            out[:] = x[:, :12].T
            return out
        S = np.zeros(n, np.float32)
        _mix_kernel(x, out, S, ch)
        S = _hp_kernel(S * np.float32(WIDTH), self.a, self.st)
        full = np.concatenate((self.hist, S))
        base = len(self.hist)
        _derive_kernel(out, full, base, n, ch <= 2, self.d8, self.d12, self.d18, self.d22,
                       SURROUND_GAIN, HEIGHT_GAIN)
        self.hist = full[-len(self.hist):].copy()
        return out


# ============================================================ ring buffer (tanpa lock/alokasi)
class Ring:
    """SPSC ring buffer numpy. push() hanya dari producer, pop()/skip() hanya dari consumer."""

    def __init__(self, ch, cap):
        self.buf = np.zeros((cap, ch), np.float32)
        self.cap, self.w, self.r, self.dropped = cap, 0, 0, 0

    @property
    def n(self):
        return self.w - self.r

    def push(self, a):
        k = a.shape[0]
        free = self.cap - (self.w - self.r)
        if k > free:
            self.dropped += k - free
            k = free
            if k <= 0:
                return
        i = self.w % self.cap
        f = min(k, self.cap - i)
        self.buf[i:i + f] = a[:f]
        if k > f:
            self.buf[:k - f] = a[f:k]
        self.w += k

    def pop(self, k, out):
        if self.w - self.r < k:
            return False
        i = self.r % self.cap
        f = min(k, self.cap - i)
        out[:f] = self.buf[i:i + f]
        if k > f:
            out[f:k] = self.buf[:k - f]
        self.r += k
        return True

    def skip(self, k):
        self.r += max(0, min(k, self.w - self.r))


def stretch(y, m):
    return _stretch_kernel(np.ascontiguousarray(y, dtype=np.float32), m)


# ============================================================ FAST binaural (numba, tanpa AVFoundation)
class FastSpatial:
    """Model kepala bola: ITD (Woodworth) + head shadow + pinna depan/belakang/tinggi + room FDN."""
    H = 128
    BASE = 40.0

    def __init__(self):
        n = len(PLAYER_IDX)
        a_head, c = 0.0875, 343.0
        ec = lambda fc: float(np.exp(-2 * np.pi * min(fc, 0.45 * SAMPLE_RATE) / SAMPLE_RATE))
        arr = lambda: np.zeros(n, np.float64)
        self.dL, self.dR, self.gL, self.gR = arr(), arr(), arr(), arr()
        self.aL, self.aR, self.a2, self.hg = arr(), arr(), arr(), arr()
        self.wL, self.wR = np.zeros(n, np.float32), np.zeros(n, np.float32)
        for i, idx in enumerate(PLAYER_IDX):
            az, el = LAYOUT[idx]
            azr, elr = np.radians(az), np.radians(el)
            lat = float(np.sin(azr) * np.cos(elr))          # + = kiri
            front = float(np.cos(azr) * np.cos(elr))        # - = belakang
            phi = float(np.arcsin(np.clip(abs(lat), 0, 1)))
            itd = ITD_SCALE * (a_head / c) * (phi + np.sin(phi)) * SAMPLE_RATE   # sampel
            if lat >= 0:
                self.dL[i], self.dR[i] = self.BASE, self.BASE + itd
            else:
                self.dL[i], self.dR[i] = self.BASE + itd, self.BASE
            for ear, e in (("L", lat), ("R", -lat)):       # e = paparan telinga terhadap sumber
                t = float(np.clip((0.15 - e) / 1.15, 0, 1)) * SHADOW
                fc = 18000.0 * (1500.0 / 18000.0) ** min(t, 1.2)
                ild = 6.0 * float(np.clip(-e, 0, 1)) * SHADOW
                g = 10.0 ** (-ild / 20.0)
                if ear == "L":
                    self.aL[i], self.gL[i] = ec(fc), g
                else:
                    self.aR[i], self.gR[i] = ec(fc), g
            rear = float(np.clip(-front, 0, 1))
            elev = float(np.clip(np.sin(elr), 0, 1))
            self.hg[i] = 1.0 - 0.55 * rear + 0.6 * elev
            self.a2[i] = ec(5000.0)
            w = 0.7 if abs(lat) < 1e-3 else 1.0
            self.wL[i] = w if lat >= -1e-3 else 0.0
            self.wR[i] = w if lat <= 1e-3 else 0.0
        self.hist = np.zeros((n, self.H), np.float32)
        self.ext = np.zeros(self.H + BLOCK, np.float32)
        self.lp2, self.lpL, self.lpR = arr(), arr(), arr()
        sc = SAMPLE_RATE / 48000.0
        self.lens = (np.array([1031, 1327, 1523, 1871]) * sc).astype(np.int64)
        self.bufs = np.zeros((4, int(self.lens.max()) + 1), np.float32)
        self.idx = np.zeros(4, np.int64)
        self.fb = 10.0 ** (-3.0 * self.lens / (SAMPLE_RATE * max(ROOM_RT60, 0.05)))
        self.dst = np.zeros(4, np.float64)
        self.da = float(np.exp(-2 * np.pi * ROOM_BRIGHT_HZ / SAMPLE_RATE))
        ms = lambda t: int(SAMPLE_RATE * t / 1000.0)
        self.pre = ms(ROOM_PREDELAY_MS)
        self.erH = ms(45.0)
        self.er_dL = np.array([ms(t) for t in (5.1, 7.3, 9.9, 12.7, 16.1, 19.7, 23.3, 27.1)], np.int64)
        self.er_dR = np.array([ms(t) for t in (5.9, 8.3, 11.1, 14.3, 17.9, 21.5, 25.3, 29.3)], np.int64)
        self.er_gL = np.array([0.55, -0.50, 0.42, -0.36, 0.30, -0.25, 0.20, -0.16], np.float64)
        self.er_gR = -self.er_gL
        self.er_sL = np.array([0, 1, 0, 1, 0, 1, 0, 1], np.int64)   # tiap tap ambil dari kiri/kanan bergantian
        self.er_sR = 1 - self.er_sL
        self.er_hist = np.zeros((2, self.erH), np.float32)
        self.er_ext = np.zeros((2, self.erH + BLOCK), np.float32)
        self.hp_a = float(np.exp(-2 * np.pi * ROOM_LOWCUT_HZ / SAMPLE_RATE))
        self.hp_stL, self.hp_stR = np.zeros(2, np.float64), np.zeros(2, np.float64)

    def selftest(self):
        pass

    def _binaural(self, f, out):
        _binaural_kernel(f, self.hist, self.ext, self.lp2, self.lpL, self.lpR, self.dL, self.dR,
                         self.gL, self.gR, self.aL, self.aR, self.a2, self.hg, out)

    def render(self, feeds):
        """feeds (11, BLOCK) float32 -> (2, BLOCK) float32 binaural."""
        f = np.ascontiguousarray(feeds, dtype=np.float32)
        out = np.zeros((2, f.shape[1]), np.float32)
        self._binaural(f, out)
        out *= np.float32(BINAURAL_GAIN)
        if ROOM_MIX > 0:
            sL = np.ascontiguousarray(self.wL @ f) * np.float32(ROOM_SEND)
            sR = np.ascontiguousarray(self.wR @ f) * np.float32(ROOM_SEND)
            sL = _hp_kernel(sL, self.hp_a, self.hp_stL)
            sR = _hp_kernel(sR, self.hp_a, self.hp_stR)
            er = np.zeros_like(out)
            prd = np.zeros_like(out)
            _early_kernel(sL, sR, self.er_hist, self.er_ext, self.er_dL, self.er_gL, self.er_sL,
                          self.er_dR, self.er_gR, self.er_sR, self.pre, er, prd)
            wet = np.float32(ROOM_EARLY * ER_CAL) * er
            if ROOM_TAIL > 0:
                rev = np.zeros_like(out)
                _fdn_kernel(prd[0], prd[1], self.bufs, self.idx, self.lens, self.fb, self.dst, self.da, rev)
                wet += np.float32(ROOM_TAIL) * rev
            out += np.float32(ROOM_MIX) * wet
        return out

    def stop(self):
        pass


# ============================================================ HRIR (SOFA) + FIR numba
def _search_dirs():
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    home = os.path.expanduser("~")
    return [here, os.getcwd()] + [os.path.join(home, d) for d in ("Downloads", "Desktop", "Documents")] + [home]


def find_sofa():
    import glob
    import os
    dirs = _search_dirs()
    if SOFA_NAME:
        if os.path.isfile(SOFA_NAME):                       # kalau terlanjur diisi path lengkap, tetap jalan
            return SOFA_NAME
        want = SOFA_NAME.lower()
        for d in dirs:
            try:
                for f in os.listdir(d):
                    if f.lower() == want:
                        return os.path.join(d, f)
            except OSError:
                pass
        return None
    for d in dirs[:2]:
        hits = sorted(glob.glob(os.path.join(d, "*.sofa")))
        if hits:
            return hits[0]
    return None


def find_plugin(name):
    import os
    home = os.path.expanduser("~")
    roots = [os.path.join(b, "Audio", "Plug-Ins", k) for b in ("/Library", os.path.join(home, "Library"))
             for k in ("VST3", "Components")]
    want = name.lower()
    for r in roots:
        try:
            for f in sorted(os.listdir(r)):
                if want in f.lower() and f.lower().endswith((".vst3", ".component")):
                    return os.path.join(r, f)
        except OSError:
            pass
    return None


def load_hrirs(path, taps):
    """Baca .sofa -> (11, 2, taps) HRIR terdekat untuk tiap speaker virtual, di SAMPLE_RATE."""
    import sofar
    sf = sofar.read_sofa(path, verbose=False)
    ir = np.asarray(sf.Data_IR, dtype=np.float64)                       # (M, 2, N)
    pos = np.asarray(sf.SourcePosition, dtype=np.float64)               # (M, 3)
    ptype = str(getattr(sf, "SourcePosition_Type", "spherical")).lower()
    if ptype.startswith("cart"):
        x, y, z = pos[:, 0], pos[:, 1], pos[:, 2]
    else:                                                               # azimuth CCW dari depan, elevasi
        a, e = np.radians(pos[:, 0]), np.radians(pos[:, 1])
        x, y, z = np.cos(e) * np.cos(a), np.cos(e) * np.sin(a), np.sin(e)
    vecs = np.stack([x, y, z], 1)
    vecs /= np.maximum(np.linalg.norm(vecs, axis=1, keepdims=True), 1e-9)
    fs_in = float(np.asarray(sf.Data_SamplingRate).ravel()[0])
    if abs(fs_in - SAMPLE_RATE) > 1:
        from scipy.signal import resample_poly
        from math import gcd
        g = gcd(int(SAMPLE_RATE), int(fs_in))
        ir = resample_poly(ir, int(SAMPLE_RATE) // g, int(fs_in) // g, axis=2)
    out = np.zeros((len(PLAYER_IDX), 2, taps), np.float32)
    fade = np.ones(taps)
    m = max(8, taps // 8)
    fade[-m:] = 0.5 * (1 + np.cos(np.linspace(0, np.pi, m)))
    for i, idx in enumerate(PLAYER_IDX):
        az, el = LAYOUT[idx]                                            # + az = kiri = CCW (konvensi SOFA)
        a, e = np.radians(az), np.radians(el)
        d = np.array([np.cos(e) * np.cos(a), np.cos(e) * np.sin(a), np.sin(e)])
        j = int(np.argmax(vecs @ d))
        h = ir[j, :, :taps] if ir.shape[2] >= taps else np.pad(ir[j], ((0, 0), (0, taps - ir.shape[2])))
        out[i] = (h * fade).astype(np.float32)
    return out[:, ::-1, :].copy() if SOFA_SWAP_EARS else out


class HRIRSpatial(FastSpatial):
    """HRTF hasil ukur (SOFA). Reverb ruang dan upmix sama dengan FAST."""

    def __init__(self):
        path = find_sofa()
        if not path:
            raise RuntimeError("file .sofa '%s' tidak ketemu (taruh di folder script / Downloads / Desktop / Documents)" % SOFA_NAME)
        super().__init__()
        h = load_hrirs(path, HRIR_TAPS)
        self.hr = np.ascontiguousarray(h[:, :, ::-1])
        n = h.shape[0]
        self.fhist = np.zeros((n, HRIR_TAPS - 1), np.float32)
        self.fext = np.zeros(HRIR_TAPS - 1 + BLOCK, np.float32)
        print("HRIR: %s (%d tap)" % (path, HRIR_TAPS))

    def _binaural(self, f, out):
        _fir_kernel(f, self.fhist, self.fext, self.hr, out)


class SPARTASpatial(FastSpatial):
    """Eksperimen: 12 kanal 7.1.4 -> plugin SPARTA Binauraliser (pedalboard). Gagal -> fallback otomatis."""

    def __init__(self):
        import pedalboard
        super().__init__()
        pp = find_plugin(SPARTA_NAME)
        if not pp:
            raise RuntimeError("plugin '%s' tidak ketemu di folder Plug-Ins" % SPARTA_NAME)
        self.plugin = pedalboard.load_plugin(pp)
        probe = np.zeros((12, BLOCK), np.float32)
        y = self.plugin.process(probe, SAMPLE_RATE, buffer_size=BLOCK, reset=False)
        if y.shape[0] < 2:
            raise RuntimeError("plugin tidak memberi output 2 kanal (pedalboard: %s)" % (y.shape,))
        self.full = np.zeros((12, BLOCK), np.float32)

    def _binaural(self, f, out):
        self.full[PLAYER_IDX] = f
        y = self.plugin.process(self.full, SAMPLE_RATE, buffer_size=BLOCK, reset=False)
        out += y[:2, :f.shape[1]]


def make_spatial():
    order = {"HRIR": ["HRIR", "FAST"], "SPARTA": ["SPARTA", "HRIR", "FAST"],
             "FAST": ["FAST"], "AV": ["AV", "FAST"]}.get(ENGINE, ["FAST"])
    ctor = {"HRIR": HRIRSpatial, "FAST": FastSpatial, "SPARTA": SPARTASpatial}
    last = None
    for name in order:
        try:
            sp = AVSpatial() if name == "AV" else ctor[name]()
            sp.selftest()
            sp.name = name
            return sp
        except Exception as e:  # noqa
            last = e
            print("engine %s tidak bisa dipakai: %r" % (name, e), flush=True)
    raise RuntimeError("semua engine gagal: %r" % (last,))


# ============================================================ Apple AV spatializer
class AVSpatial:
    def __init__(self):
        import objc
        import AVFoundation as AV
        self.objc, self.AV = objc, AV
        g = lambda name, default: getattr(AV, name, default)
        alg = {"HRTFHQ": g("AVAudio3DMixingRenderingAlgorithmHRTFHQ", 6),
               "HRTF": g("AVAudio3DMixingRenderingAlgorithmHRTF", 2),
               "SphericalHead": g("AVAudio3DMixingRenderingAlgorithmSphericalHead", 1),
               "EqualPowerPanning": g("AVAudio3DMixingRenderingAlgorithmEqualPowerPanning", 0)}[RENDERING]
        self.success = g("AVAudioEngineManualRenderingStatusSuccess", 0)

        fmt = AV.AVAudioFormat.alloc()
        self.mono = fmt.initStandardFormatWithSampleRate_channels_(float(SAMPLE_RATE), 1)
        self.stereo = AV.AVAudioFormat.alloc().initStandardFormatWithSampleRate_channels_(float(SAMPLE_RATE), 2)

        self.engine = AV.AVAudioEngine.alloc().init()
        self.env = AV.AVAudioEnvironmentNode.alloc().init()
        self.env.setOutputType_(g("AVAudioEnvironmentOutputTypeHeadphones", 1))
        dp = self.env.distanceAttenuationParameters()
        dp.setDistanceAttenuationModel_(g("AVAudioEnvironmentDistanceAttenuationModelInverse", 2))
        dp.setReferenceDistance_(float(SPEAKER_DISTANCE))
        dp.setMaximumDistance_(100.0)
        dp.setRolloffFactor_(1.0)
        rp = self.env.reverbParameters()
        rp.setEnable_(REVERB_BLEND > 0)
        if REVERB_BLEND > 0:
            rp.loadFactoryReverbPreset_(g("AVAudioUnitReverbPresetSmallRoom", 0))

        self.engine.attachNode_(self.env)
        self.engine.connect_to_format_(self.env, self.engine.mainMixerNode(), self.stereo)
        self.players = []
        for idx in PLAYER_IDX:
            p = AV.AVAudioPlayerNode.alloc().init()
            self.engine.attachNode_(p)
            self.engine.connect_to_format_(p, self.env, self.mono)
            p.setSourceMode_(g("AVAudio3DMixingSourceModeSpatializeIfMono", 0))
            p.setRenderingAlgorithm_(alg)
            p.setReverbBlend_(float(REVERB_BLEND))
            x, y, z = az_el_to_xyz(*LAYOUT[idx], SPEAKER_DISTANCE)
            p.setPosition_(self._pt(x, y, z))
            self.players.append(p)

        ok, err = self.engine.enableManualRenderingMode_format_maximumFrameCount_error_(
            g("AVAudioEngineManualRenderingModeOffline", 0), self.stereo, BLOCK, None)
        if not ok:
            raise RuntimeError("manual rendering gagal: %s" % err)
        ok, err = self.engine.startAndReturnError_(None)
        if not ok:
            raise RuntimeError("engine gagal start: %s" % err)
        for p in self.players:
            p.play()
        self.outbuf = AV.AVAudioPCMBuffer.alloc().initWithPCMFormat_frameCapacity_(self.stereo, BLOCK)
        self.outv = (self._chan(self.outbuf, 0, BLOCK), self._chan(self.outbuf, 1, BLOCK))
        # pool buffer dipakai ulang: tidak ada alokasi AVAudioPCMBuffer per blok
        self.POOL, self.k, self.pool = 4, 0, []
        for _ in self.players:
            row = []
            for _ in range(self.POOL):
                b = AV.AVAudioPCMBuffer.alloc().initWithPCMFormat_frameCapacity_(self.mono, BLOCK)
                b.setFrameLength_(BLOCK)
                row.append((b, self._chan(b, 0, BLOCK)))
            self.pool.append(row)

    def _pt(self, x, y, z):
        """AVAudio3DPointMake adalah fungsi inline, tidak selalu diekspos pyobjc -> coba beberapa cara."""
        AV = self.AV
        if hasattr(AV, "AVAudio3DPointMake"):
            return AV.AVAudio3DPointMake(x, y, z)
        if hasattr(AV, "AVAudio3DPoint"):
            try:
                return AV.AVAudio3DPoint(x, y, z)
            except Exception:
                pass
        return (x, y, z)  # pyobjc menerima tuple untuk argumen struct

    @staticmethod
    def _chan(buf, c, n):
        return np.frombuffer(buf.floatChannelData()[c].as_buffer(n), dtype=np.float32, count=n)

    def selftest(self):
        """Pastikan buffer AV bisa ditulis/dibaca dari numpy."""
        buf = self.AV.AVAudioPCMBuffer.alloc().initWithPCMFormat_frameCapacity_(self.mono, 64)
        buf.setFrameLength_(64)
        v = self._chan(buf, 0, 64)
        v[:] = np.arange(64, dtype=np.float32)
        if not np.allclose(self._chan(buf, 0, 64), np.arange(64)):
            raise RuntimeError("buffer AV tidak bisa ditulis dari numpy (cek versi pyobjc)")

    def render(self, feeds):
        """feeds (11, BLOCK) float32 -> (2, BLOCK) float32 binaural."""
        slot = self.k % self.POOL
        self.k += 1
        for p, row, pl in zip(self.players, feeds, self.pool):
            buf, view = pl[slot]
            view[:] = row
            p.scheduleBuffer_completionHandler_(buf, None)
        status, err = self.engine.renderOffline_toBuffer_error_(BLOCK, self.outbuf, None)
        if status != self.success:
            raise RuntimeError("renderOffline status=%s err=%s" % (status, err))
        n = min(int(self.outbuf.frameLength()), BLOCK)
        out = np.zeros((2, BLOCK), np.float32)
        out[0, :n] = self.outv[0][:n]
        out[1, :n] = self.outv[1][:n]
        return out

    def stop(self):
        try:
            for p in self.players:
                p.stop()
            self.engine.stop()
        except Exception:
            pass


# ============================================================ limiter
try:
    from pedalboard import Limiter, Pedalboard
    _board = Pedalboard([Limiter(threshold_db=LIMITER_THRESHOLD_DB, release_ms=LIMITER_RELEASE_MS)])

    def limit(y):
        return np.clip(_board(y, SAMPLE_RATE, reset=False), -0.999, 0.999)
except Exception:
    def limit(y):  # fallback tanpa pedalboard
        return _tanh_kernel(np.ascontiguousarray(y, dtype=np.float32))


# ============================================================ device
def find_devices():
    devs = sd.query_devices()
    in_idx = next((i for i, d in enumerate(devs)
                   if INPUT_DEVICE_NAME.lower() in d["name"].lower() and d["max_input_channels"] > 0), None)
    out_idx = None
    for cand in OUTPUT_DEVICE_CANDIDATES:
        for i, d in enumerate(devs):
            if (cand.lower() in d["name"].lower() and d["max_output_channels"] >= 2
                    and INPUT_DEVICE_NAME.lower() not in d["name"].lower()):
                out_idx = i
                break
        if out_idx is not None:
            break
    return devs, in_idx, out_idx


# ============================================================ prioritas proses (macOS)
def boost_thread():
    """Thread worker = QOS user-interactive (dijadwalkan seperti audio/UI, bukan background)."""
    try:
        import ctypes
        ctypes.CDLL("libSystem.dylib").pthread_set_qos_class_self_np(0x21, 0)
    except Exception:
        pass


def no_app_nap():
    """Matikan App Nap / timer coalescing untuk proses ini. Simpan return value selama program jalan."""
    try:
        from Foundation import NSProcessInfo
        return NSProcessInfo.processInfo().beginActivityWithOptions_reason_(
            0x00FFFFFF | 0xFF00000000, "Soidyn realtime audio")
    except Exception:
        return None


# ============================================================ pipeline
class Pipeline:
    """Input ring -> upmix -> spatial -> limiter -> output ring, dengan jitter buffer adaptif."""

    def __init__(self, n_in, spat=None):
        self.n_in, self.spat = n_in, spat
        self.inq = Ring(n_in, 24 * BLOCK)
        self.outq = Ring(2, 24 * BLOCK)
        self.target = OUT_TARGET_BLOCKS * BLOCK
        self.max_target = MAX_TARGET_BLOCKS * BLOCK
        self.primed = False
        self.fade_in = False
        self.under = self.pa_in = self.pa_out = self.drops = 0
        self.ms = self.ms_max = 0.0
        self.upmix = Upmixer()
        self.xbuf = np.empty((BLOCK, n_in), np.float32)
        self.ramp = np.linspace(0.0, 1.0, 96, dtype=np.float32)[:, None]
        self.ev = threading.Event()
        self.ready = threading.Event()
        self.alive = True
        self.err = None
        self.blocks = 0
        self.soft_blocks = max(1, int(SOFT_START_SEC * SAMPLE_RATE / BLOCK))
        self.gain_prev = 0.0

    # ---- callback PortAudio (dibuat sesingkat mungkin)
    def in_cb(self, indata, frames, t, status):
        if status:
            self.pa_in += 1
        self.inq.push(indata[:, :self.n_in])
        if self.inq.n >= BLOCK:
            self.ev.set()

    def out_cb(self, outdata, frames, t, status):
        if status:
            self.pa_out += 1
        q = self.outq
        if not self.primed:
            if q.n < self.target:
                outdata.fill(0)
                return
            self.primed = True
            self.fade_in = True
        if q.pop(frames, outdata):
            if self.fade_in:
                m = min(len(self.ramp), frames)
                outdata[:m] *= self.ramp[:m]
                self.fade_in = False
            return
        n = q.n                                   # underrun: habiskan sisa dengan fade-out, lalu isi ulang buffer
        if n > 0:
            q.pop(n, outdata[:n])
            m = min(n, 96)
            outdata[n - m:n] *= self.ramp[:m][::-1]
        outdata[n:] = 0
        self.under += 1
        self.primed = False
        self.target = min(self.target + BLOCK, self.max_target)

    # ---- satu langkah proses (satu blok)
    def step(self):
        inq = self.inq
        if inq.n > 8 * BLOCK:                    # input menumpuk (worker sempat tertahan): buang yang terlalu tua
            inq.skip(inq.n - 4 * BLOCK)
            self.drops += 1
        if not inq.pop(BLOCK, self.xbuf):
            return False
        t0 = time.perf_counter()
        bed = self.upmix.process(self.xbuf * np.float32(INPUT_GAIN))
        spat = self.spat.render(np.ascontiguousarray(bed[PLAYER_IDX]))
        g_now = min(1.0, (self.blocks + 1) / self.soft_blocks) * BOOSTER * MASTER_GAIN
        gains = np.linspace(self.gain_prev, g_now, BLOCK, dtype=np.float32)
        self.gain_prev = g_now
        self.blocks += 1
        y = (spat + (bed[LFE_INDEX] * LFE_GAIN)[None, :]) * gains[None, :]
        y = limit(np.ascontiguousarray(y, dtype=np.float32))
        lvl, ref = self.outq.n, self.target - BLOCK     # koreksi drift antar clock (+-1 sampel/blok)
        if lvl > ref + int(1.5 * BLOCK):
            y = stretch(y, BLOCK - 1)
        elif lvl < ref - BLOCK // 2:
            y = stretch(y, BLOCK + 1)
        self.outq.push(np.ascontiguousarray(y.T))
        dt = (time.perf_counter() - t0) * 1000.0
        self.ms += (dt - self.ms) * 0.05
        self.ms_max = max(self.ms_max * 0.999, dt)
        return True

    def run(self):
        boost_thread()
        try:
            if self.spat is None:
                self.spat = make_spatial()
            self.spat.selftest()
        except Exception as e:  # noqa
            self.err = e
            self.ready.set()
            return
        self.ready.set()
        try:
            while self.alive:
                if not self.step():
                    self.ev.wait(0.002)
                    self.ev.clear()
        except Exception as e:  # noqa
            self.err = e
            self.alive = False
        finally:
            self.spat.stop()


def main():
    devs, in_idx, out_idx = find_devices()
    if in_idx is None:
        sys.exit("Device '%s' tidak ditemukan. Daftar device:\n%s" % (INPUT_DEVICE_NAME, sd.query_devices()))
    if out_idx is None:
        sys.exit("Built-In Output tidak ketemu. Tambahkan namanya ke OUTPUT_DEVICE_CANDIDATES:\n%s" % sd.query_devices())
    n_in = INPUT_CHANNELS or min(12, devs[in_idx]["max_input_channels"])
    print("in : [%d] %s (%d ch)\nout: [%d] %s\nengine: %s | booster x%g" % (
        in_idx, devs[in_idx]["name"], n_in, out_idx, devs[out_idx]["name"], ENGINE, BOOSTER))

    print("numba: compile/load kernel..." if HAS_NUMBA else "numba tidak terpasang (pip3 install numba) -> berat.", flush=True)
    warmup()

    pipe = Pipeline(n_in)
    th = threading.Thread(target=pipe.run, daemon=True)
    th.start()
    pipe.ready.wait()
    if pipe.err:
        sys.exit("engine gagal: %r\n(ENGINE AV: pip3 install pyobjc-framework-AVFoundation ; macOS 10.15+)" % (pipe.err,))

    nap = no_app_nap()                      # noqa: F841 (harus tetap dirujuk)
    sys.setswitchinterval(0.001)            # GIL dilepas lebih sering -> callback audio tidak menunggu 5 ms
    gc.collect()
    gc.disable()                            # tidak ada jeda GC di tengah audio

    with sd.InputStream(device=in_idx, channels=n_in, samplerate=SAMPLE_RATE, blocksize=PA_BLOCK,
                        dtype="float32", latency=PA_LATENCY, callback=pipe.in_cb), \
         sd.OutputStream(device=out_idx, channels=2, samplerate=SAMPLE_RATE, blocksize=PA_BLOCK,
                         dtype="float32", latency=PA_LATENCY, callback=pipe.out_cb):
        print("jalan: engine %s (Ctrl+C untuk berhenti). Set output macOS ke '%s'." % (pipe.spat.name, INPUT_DEVICE_NAME))
        try:
            while pipe.alive:
                time.sleep(2)
                print("\rproc %.2f/%.2f ms (budget %.1f) | buf %3.0f ms | underrun=%d  pa_in=%d pa_out=%d drop=%d   "
                      % (pipe.ms, pipe.ms_max, 1000.0 * BLOCK / SAMPLE_RATE, 1000.0 * pipe.target / SAMPLE_RATE,
                         pipe.under, pipe.pa_in, pipe.pa_out, pipe.drops), end="", flush=True)
        except KeyboardInterrupt:
            pass
    pipe.alive = False
    th.join(timeout=2)
    if pipe.err:
        print("\nerror: %r" % (pipe.err,))


if __name__ == "__main__":
    main()