#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Soidyn AV - renderer binaural gaya Atmos, full Python, spatializer = Apple AVFoundation.

  Soidyn Driver (7.1.4 / 7.1 / 5.1 / stereo)
      -> upmix ke 7.1.4 (numpy + numba JIT)
      -> AVAudioEngine (manual rendering) : 11 sumber mono, masing-masing AVAudioPlayerNode
         diposisikan 3D di AVAudioEnvironmentNode (HRTFHQ Apple)
      -> LFE + master + limiter (pedalboard)
      -> Built-In Output

Install : pip3 install numpy numba sounddevice pyobjc-framework-AVFoundation pedalboard scipy
Jalankan: python3 soidyn_av.py        (semua pengaturan = konstanta di bawah, tanpa command)
Pakai headphone di jack Built-In. Binaural tidak cocok untuk speaker laptop.
Run pertama numba compile sekitar beberapa detik, setelahnya di-cache (cache=True).
"""
import sys
import threading
import time
from collections import deque

import numpy as np
import sounddevice as sd

try:
    from numba import njit
    HAS_NUMBA = True
except Exception:  # numba tidak ada -> jalan lambat tanpa JIT
    HAS_NUMBA = False

    def njit(*a, **k):
        if len(a) == 1 and callable(a[0]) and not k:
            return a[0]
        return lambda f: f

# ============================================================ PENGATURAN (konstanta)
INPUT_DEVICE_NAME = "Soidyn Driver"
OUTPUT_DEVICE_CANDIDATES = ("Built-in Output", "MacBook Pro Speakers", "MacBook Air Speakers",
                            "External Headphones", "Headphones", "Speakers")
SAMPLE_RATE = 48000
INPUT_CHANNELS = None          # None = otomatis (maks 12). Isi angka kalau mau dipaksa.
INPUT_CHANNEL_MAP = None       # reorder kanal input, mis. [0,1,2,3,4,5,6,7,8,9,10,11]
PA_BLOCK = 512                 # blok PortAudio (10.7 ms)
BLOCK = 512                    # frame per render AV (10.7 ms). Kalau masih patah, coba 1024
OUT_TARGET_BLOCKS = 3          # buffer output (3 x 10.7 ms). Kalau stabil bisa 2, kalau masih klik naikkan

SPEAKER_DISTANCE = 1.5         # meter, jarak 11 speaker virtual dari kepala
RENDERING = "HRTFHQ"           # HRTFHQ | HRTF | SphericalHead | EqualPowerPanning  (kalau CPU berat: "HRTF")
REVERB_BLEND = 0.0             # 0 = kering (studio). 0.1-0.3 = ada nuansa ruang
INPUT_GAIN = 1.0
MASTER_GAIN = 1.0
LFE_GAIN = 0.7
LIMITER_THRESHOLD_DB = -1.0
LIMITER_RELEASE_MS = 120.0

# ============================================================ layout 7.1.4 (urutan = Soidyn Driver / Atmos)
# L R C LFE Ls Rs Lrs Rrs Ltf Rtf Ltr Rtr  -> (azimuth derajat, + = kiri ; elevasi derajat)
LAYOUT = [(30, 0), (-30, 0), (0, 0), (0, 0), (90, 0), (-90, 0), (150, 0), (-150, 0),
          (45, 45), (-45, 45), (135, 45), (-135, 45)]
LFE_INDEX = 3
PLAYER_IDX = [i for i in range(12) if i != LFE_INDEX]


def az_el_to_xyz(az_deg, el_deg, d):
    """AVAudio3DPoint: +x kanan, +y atas, +z ke belakang (pendengar menghadap -z)."""
    az, el = np.radians(az_deg), np.radians(el_deg)
    return (float(-np.sin(az) * np.cos(el) * d), float(np.sin(el) * d), float(-np.cos(az) * np.cos(el) * d))


# ============================================================ kernel numba
@njit(cache=True, fastmath=True)
def _hp_kernel(x, a, st):
    """One-pole highpass: y[n] = a*(x[n]-x[n-1]) + a*y[n-1]. st = [x_prev, y_prev]."""
    n = x.shape[0]
    y = np.empty(n, np.float32)
    xp = st[0]
    yp = st[1]
    for i in range(n):
        xi = x[i]
        yi = a * (xi - xp) + a * yp
        y[i] = yi
        xp = xi
        yp = yi
    st[0] = xp
    st[1] = yp
    return y


@njit(cache=True, fastmath=True)
def _mix_kernel(x, out, S, ch):
    """x (n, ch) -> out (12, n) bed + S (sinyal samping untuk turunan tinggi/surround)."""
    n = x.shape[0]
    for i in range(n):
        if ch <= 2:
            L = x[i, 0]
            if ch > 1:
                R = x[i, 1]
            else:
                R = L
            M = 0.5 * (L + R)
            S[i] = 0.5 * (L - R)
            out[0, i] = L - 0.2 * M
            out[1, i] = R - 0.2 * M
            out[2, i] = 0.35 * M
        else:
            m = ch if ch < 8 else 8
            for c in range(m):
                out[c, i] = x[i, c]
            L = x[i, 0]
            R = x[i, 1]
            Ls = x[i, 4] if ch > 4 else 0.0
            Rs = x[i, 5] if ch > 5 else 0.0
            Lrs = x[i, 6] if ch >= 8 else 0.0
            Rrs = x[i, 7] if ch >= 8 else 0.0
            S[i] = 0.5 * ((L + Ls + Lrs) - (R + Rs + Rrs))


@njit(cache=True, fastmath=True)
def _derive_kernel(out, full, base, n, stereo, d8, d12, d18, d22):
    """Isi kanal tinggi (dan surround untuk stereo) dari delay line sinyal samping."""
    for i in range(n):
        out[8, i] = 0.30 * full[base - d8 + i]
        out[9, i] = -0.30 * full[base - d8 + i]
        out[10, i] = 0.25 * full[base - d18 + i]
        out[11, i] = -0.25 * full[base - d18 + i]
        if stereo:
            out[4, i] = 0.5 * full[base - d12 + i]
            out[5, i] = -0.5 * full[base - d12 + i]
            out[6, i] = 0.35 * full[base - d22 + i]
            out[7, i] = -0.35 * full[base - d22 + i]


@njit(cache=True, fastmath=True)
def _stretch_kernel(y, m):
    """(2, n) -> (2, m) interpolasi linear, koreksi drift clock +-1 sampel per blok."""
    c = y.shape[0]
    n = y.shape[1]
    out = np.empty((c, m), np.float32)
    scale = (n - 1) / (m - 1) if m > 1 else 0.0
    for ch in range(c):
        for j in range(m):
            p = j * scale
            i0 = int(p)
            if i0 >= n - 1:
                out[ch, j] = y[ch, n - 1]
            else:
                f = p - i0
                out[ch, j] = y[ch, i0] * (1.0 - f) + y[ch, i0 + 1] * f
    return out


@njit(cache=True, fastmath=True)
def _tanh_kernel(y):
    out = np.empty_like(y)
    f = y.reshape(-1)
    o = out.reshape(-1)
    for i in range(f.shape[0]):
        o[i] = np.tanh(f[i])
    return out


def warmup():
    """Compile semua kernel sebelum audio jalan supaya tidak ada glitch di blok pertama."""
    x = np.zeros((BLOCK, 2), np.float32)
    out = np.zeros((12, BLOCK), np.float32)
    S = np.zeros(BLOCK, np.float32)
    st = np.zeros(2, np.float64)
    _hp_kernel(S, 0.97, st)
    _mix_kernel(x, out, S, 2)
    _mix_kernel(np.zeros((BLOCK, 8), np.float32), out, S, 8)
    full = np.zeros(BLOCK * 4, np.float32)
    _derive_kernel(out, full, BLOCK * 2, BLOCK, True, 10, 20, 30, 40)
    y = np.zeros((2, BLOCK), np.float32)
    _stretch_kernel(y, BLOCK - 1)
    _stretch_kernel(y, BLOCK + 1)
    _tanh_kernel(y)


# ============================================================ upmixer
class Upmixer:
    """Input (n, ch) -> (12, n) urutan 7.1.4. Tinggi/surround diturunkan dari sinyal samping."""

    def __init__(self):
        self.hist = np.zeros(int(SAMPLE_RATE * 0.03), np.float32)
        self.a = float(np.exp(-2 * np.pi * 250.0 / SAMPLE_RATE))
        self.st = np.zeros(2, np.float64)
        ms = lambda t: int(SAMPLE_RATE * t / 1000.0)
        self.d8, self.d12, self.d18, self.d22 = ms(8), ms(12), ms(18), ms(22)

    def process(self, x):
        if INPUT_CHANNEL_MAP:
            x = x[:, INPUT_CHANNEL_MAP]
        x = np.ascontiguousarray(x, dtype=np.float32)
        n, ch = x.shape
        out = np.zeros((12, n), np.float32)
        if ch >= 12:                       # sudah 7.1.4
            out[:] = x[:, :12].T
            return out
        S = np.zeros(n, np.float32)
        _mix_kernel(x, out, S, ch)
        S = _hp_kernel(S, self.a, self.st)
        full = np.concatenate((self.hist, S))
        base = len(self.hist)
        _derive_kernel(out, full, base, n, ch <= 2, self.d8, self.d12, self.d18, self.d22)
        self.hist = full[-len(self.hist):].copy()
        return out


# ============================================================ queue frame sederhana
class FrameQueue:
    def __init__(self, ch, max_frames):
        self.ch, self.max, self.q, self.n, self.lock = ch, max_frames, deque(), 0, threading.Lock()

    def push(self, a):
        with self.lock:
            self.q.append(a)
            self.n += len(a)
            while self.n > self.max:
                self.n -= len(self.q.popleft())

    def pop(self, k):
        with self.lock:
            if self.n < k:
                return None
            parts, need = [], k
            while need:
                c = self.q.popleft()
                if len(c) > need:
                    self.q.appendleft(c[need:])
                    c = c[:need]
                parts.append(c)
                need -= len(c)
            self.n -= k
        return parts[0] if len(parts) == 1 else np.concatenate(parts)


def stretch(y, m):
    return _stretch_kernel(np.ascontiguousarray(y, dtype=np.float32), m)


# ============================================================ Apple AV spatializer
class AVSpatial:
    def __init__(self):
        import objc
        import AVFoundation as AV
        self.objc, self.AV = objc, AV
        g = lambda name, default: getattr(AV, name, default)
        alg = {"HRTFHQ": g("AVAudio3DMixingRenderingAlgorithmHRTFHQ", 6),
               "HRTF": g("AVAudio3DMixingRenderingAlgorithmHRTF", 2),
               "SphericalHead": g("AVAudio3DMixingRenderingAlgorithmSphericalHead", 1),
               "EqualPowerPanning": g("AVAudio3DMixingRenderingAlgorithmEqualPowerPanning", 0)}[RENDERING]
        self.success = g("AVAudioEngineManualRenderingStatusSuccess", 0)

        fmt = AV.AVAudioFormat.alloc()
        self.mono = fmt.initStandardFormatWithSampleRate_channels_(float(SAMPLE_RATE), 1)
        self.stereo = AV.AVAudioFormat.alloc().initStandardFormatWithSampleRate_channels_(float(SAMPLE_RATE), 2)

        self.engine = AV.AVAudioEngine.alloc().init()
        self.env = AV.AVAudioEnvironmentNode.alloc().init()
        self.env.setOutputType_(g("AVAudioEnvironmentOutputTypeHeadphones", 1))
        dp = self.env.distanceAttenuationParameters()
        dp.setDistanceAttenuationModel_(g("AVAudioEnvironmentDistanceAttenuationModelInverse", 2))
        dp.setReferenceDistance_(float(SPEAKER_DISTANCE))
        dp.setMaximumDistance_(100.0)
        dp.setRolloffFactor_(1.0)
        rp = self.env.reverbParameters()
        rp.setEnable_(REVERB_BLEND > 0)
        if REVERB_BLEND > 0:
            rp.loadFactoryReverbPreset_(g("AVAudioUnitReverbPresetSmallRoom", 0))

        self.engine.attachNode_(self.env)
        self.engine.connect_to_format_(self.env, self.engine.mainMixerNode(), self.stereo)
        self.players = []
        for idx in PLAYER_IDX:
            p = AV.AVAudioPlayerNode.alloc().init()
            self.engine.attachNode_(p)
            self.engine.connect_to_format_(p, self.env, self.mono)
            p.setSourceMode_(g("AVAudio3DMixingSourceModeSpatializeIfMono", 0))
            p.setRenderingAlgorithm_(alg)
            p.setReverbBlend_(float(REVERB_BLEND))
            x, y, z = az_el_to_xyz(*LAYOUT[idx], SPEAKER_DISTANCE)
            p.setPosition_(self._pt(x, y, z))
            self.players.append(p)

        ok, err = self.engine.enableManualRenderingMode_format_maximumFrameCount_error_(
            g("AVAudioEngineManualRenderingModeOffline", 0), self.stereo, BLOCK, None)
        if not ok:
            raise RuntimeError("manual rendering gagal: %s" % err)
        ok, err = self.engine.startAndReturnError_(None)
        if not ok:
            raise RuntimeError("engine gagal start: %s" % err)
        for p in self.players:
            p.play()
        self.outbuf = AV.AVAudioPCMBuffer.alloc().initWithPCMFormat_frameCapacity_(self.stereo, BLOCK)
        self.outv = (self._chan(self.outbuf, 0, BLOCK), self._chan(self.outbuf, 1, BLOCK))
        # pool buffer dipakai ulang: tidak ada alokasi AVAudioPCMBuffer per blok
        self.POOL, self.k, self.pool = 4, 0, []
        for _ in self.players:
            row = []
            for _ in range(self.POOL):
                b = AV.AVAudioPCMBuffer.alloc().initWithPCMFormat_frameCapacity_(self.mono, BLOCK)
                b.setFrameLength_(BLOCK)
                row.append((b, self._chan(b, 0, BLOCK)))
            self.pool.append(row)

    def _pt(self, x, y, z):
        """AVAudio3DPointMake adalah fungsi inline, tidak selalu diekspos pyobjc -> coba beberapa cara."""
        AV = self.AV
        if hasattr(AV, "AVAudio3DPointMake"):
            return AV.AVAudio3DPointMake(x, y, z)
        if hasattr(AV, "AVAudio3DPoint"):
            try:
                return AV.AVAudio3DPoint(x, y, z)
            except Exception:
                pass
        return (x, y, z)  # pyobjc menerima tuple untuk argumen struct

    @staticmethod
    def _chan(buf, c, n):
        return np.frombuffer(buf.floatChannelData()[c].as_buffer(n), dtype=np.float32, count=n)

    def selftest(self):
        """Pastikan buffer AV bisa ditulis/dibaca dari numpy."""
        buf = self.AV.AVAudioPCMBuffer.alloc().initWithPCMFormat_frameCapacity_(self.mono, 64)
        buf.setFrameLength_(64)
        v = self._chan(buf, 0, 64)
        v[:] = np.arange(64, dtype=np.float32)
        if not np.allclose(self._chan(buf, 0, 64), np.arange(64)):
            raise RuntimeError("buffer AV tidak bisa ditulis dari numpy (cek versi pyobjc)")

    def render(self, feeds):
        """feeds (11, BLOCK) float32 -> (2, BLOCK) float32 binaural."""
        slot = self.k % self.POOL
        self.k += 1
        for p, row, pl in zip(self.players, feeds, self.pool):
            buf, view = pl[slot]
            view[:] = row
            p.scheduleBuffer_completionHandler_(buf, None)
        status, err = self.engine.renderOffline_toBuffer_error_(BLOCK, self.outbuf, None)
        if status != self.success:
            raise RuntimeError("renderOffline status=%s err=%s" % (status, err))
        n = min(int(self.outbuf.frameLength()), BLOCK)
        out = np.zeros((2, BLOCK), np.float32)
        out[0, :n] = self.outv[0][:n]
        out[1, :n] = self.outv[1][:n]
        return out

    def stop(self):
        try:
            for p in self.players:
                p.stop()
            self.engine.stop()
        except Exception:
            pass


# ============================================================ limiter
try:
    from pedalboard import Limiter, Pedalboard
    _board = Pedalboard([Limiter(threshold_db=LIMITER_THRESHOLD_DB, release_ms=LIMITER_RELEASE_MS)])

    def limit(y):
        return np.clip(_board(y, SAMPLE_RATE, reset=False), -0.999, 0.999)
except Exception:
    def limit(y):  # fallback tanpa pedalboard
        return _tanh_kernel(np.ascontiguousarray(y, dtype=np.float32))


# ============================================================ device & main
def find_devices():
    devs = sd.query_devices()
    in_idx = next((i for i, d in enumerate(devs)
                   if INPUT_DEVICE_NAME.lower() in d["name"].lower() and d["max_input_channels"] > 0), None)
    out_idx = None
    for cand in OUTPUT_DEVICE_CANDIDATES:
        for i, d in enumerate(devs):
            if (cand.lower() in d["name"].lower() and d["max_output_channels"] >= 2
                    and INPUT_DEVICE_NAME.lower() not in d["name"].lower()):
                out_idx = i
                break
        if out_idx is not None:
            break
    return devs, in_idx, out_idx


def main():
    devs, in_idx, out_idx = find_devices()
    if in_idx is None:
        sys.exit("Device '%s' tidak ditemukan. Daftar device:\n%s" % (INPUT_DEVICE_NAME, sd.query_devices()))
    if out_idx is None:
        sys.exit("Built-In Output tidak ketemu. Tambahkan namanya ke OUTPUT_DEVICE_CANDIDATES:\n%s" % sd.query_devices())
    n_in = INPUT_CHANNELS or min(12, devs[in_idx]["max_input_channels"])
    print("in : [%d] %s (%d ch)\nout: [%d] %s" % (in_idx, devs[in_idx]["name"], n_in, out_idx, devs[out_idx]["name"]))

    if HAS_NUMBA:
        print("numba: compile/load kernel...", flush=True)
    else:
        print("numba tidak terpasang (pip3 install numba) -> jalan tanpa JIT, bakal berat.")
    warmup()

    inq = FrameQueue(n_in, SAMPLE_RATE)
    outq = FrameQueue(2, SAMPLE_RATE)
    target = OUT_TARGET_BLOCKS * BLOCK
    state = {"primed": False, "under": 0, "run": True, "err": None, "ready": threading.Event(),
             "ev": threading.Event(), "ms": 0.0, "ms_max": 0.0}
    upmix = Upmixer()

    def worker():
        av = None
        try:
            av = AVSpatial()
            av.selftest()
        except Exception as e:  # noqa
            state["err"] = e
            state["ready"].set()
            return
        state["ready"].set()
        try:
            while state["run"]:
                while inq.n > 4 * BLOCK:           # buang backlog supaya latensi tidak menumpuk
                    inq.pop(BLOCK)
                x = inq.pop(BLOCK)
                if x is None:
                    state["ev"].wait(0.01)
                    state["ev"].clear()
                    continue
                t0 = time.perf_counter()
                bed = upmix.process(x * INPUT_GAIN)
                spat = av.render(np.ascontiguousarray(bed[PLAYER_IDX]))
                y = (spat + (bed[LFE_INDEX] * LFE_GAIN)[None, :]) * MASTER_GAIN
                y = limit(np.ascontiguousarray(y, dtype=np.float32))
                lvl = outq.n                        # koreksi drift antar clock
                if lvl > target + int(1.5 * BLOCK):
                    y = stretch(y, BLOCK - 1)
                elif lvl < target - BLOCK // 2:
                    y = stretch(y, BLOCK + 1)
                outq.push(np.ascontiguousarray(y.T))
                dt = (time.perf_counter() - t0) * 1000.0
                state["ms"] += (dt - state["ms"]) * 0.05
                state["ms_max"] = max(state["ms_max"] * 0.999, dt)
        except Exception as e:  # noqa
            state["err"] = e
            state["run"] = False
        finally:
            av.stop()

    def in_cb(indata, frames, t, status):
        inq.push(indata[:, :n_in].copy())
        if inq.n >= BLOCK:
            state["ev"].set()

    def out_cb(outdata, frames, t, status):
        if not state["primed"]:
            if outq.n >= target:
                state["primed"] = True
            else:
                outdata.fill(0)
                return
        y = outq.pop(frames)
        if y is None:
            state["under"] += 1
            state["primed"] = False
            outdata.fill(0)
        else:
            outdata[:] = y

    th = threading.Thread(target=worker, daemon=True)
    th.start()
    state["ready"].wait()
    if state["err"]:
        sys.exit("AV engine gagal: %r\n(pip3 install pyobjc-framework-AVFoundation ; macOS 10.15+)" % (state["err"],))

    with sd.InputStream(device=in_idx, channels=n_in, samplerate=SAMPLE_RATE, blocksize=PA_BLOCK,
                        dtype="float32", latency="low", callback=in_cb), \
         sd.OutputStream(device=out_idx, channels=2, samplerate=SAMPLE_RATE, blocksize=PA_BLOCK,
                         dtype="float32", latency="low", callback=out_cb):
        print("jalan (Ctrl+C untuk berhenti). Set output macOS ke '%s'." % INPUT_DEVICE_NAME)
        try:
            while state["run"]:
                time.sleep(2)
                print("\rproc avg=%.2f max=%.2f ms (budget %.2f) | in=%d out=%d fr | underrun=%d   "
                      % (state["ms"], state["ms_max"], 1000.0 * BLOCK / SAMPLE_RATE, inq.n, outq.n, state["under"]),
                      end="", flush=True)
        except KeyboardInterrupt:
            pass
    state["run"] = False
    th.join(timeout=2)
    if state["err"]:
        print("\nerror: %r" % (state["err"],))


if __name__ == "__main__":
    main()