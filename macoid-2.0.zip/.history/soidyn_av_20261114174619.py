v#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Soidyn AV - renderer binaural gaya Atmos, full Python, spatializer = Apple AVFoundation.

  Soidyn Driver (7.1.4 / 7.1 / 5.1 / stereo)
      -> upmix ke 7.1.4 (numpy)
      -> AVAudioEngine (manual rendering) : 11 sumber mono, masing-masing AVAudioPlayerNode
         diposisikan 3D di AVAudioEnvironmentNode (HRTFHQ Apple)
      -> LFE + master + limiter (pedalboard)
      -> Built-In Output

Install : pip3 install numpy sounddevice pyobjc-framework-AVFoundation pedalboard scipy
Jalankan: python3 soidyn_av.py        (semua pengaturan = konstanta di bawah, tanpa command)
Pakai headphone di jack Built-In. Binaural tidak cocok untuk speaker laptop.
"""
import sys
import threading
import time
from collections import deque

import numpy as np
import sounddevice as sd

# ============================================================ PENGATURAN (konstanta)
INPUT_DEVICE_NAME = "Soidyn Driver"
OUTPUT_DEVICE_CANDIDATES = ("Built-in Output", "MacBook Pro Speakers", "MacBook Air Speakers",
                            "External Headphones", "Headphones", "Speakers")
SAMPLE_RATE = 48000
INPUT_CHANNELS = None          # None = otomatis (maks 12). Isi angka kalau mau dipaksa.
INPUT_CHANNEL_MAP = None       # reorder kanal input, mis. [0,1,2,3,4,5,6,7,8,9,10,11]
PA_BLOCK = 256                 # blok PortAudio
BLOCK = 512                    # frame per render AV (naikkan ke 1024 kalau CPU kewalahan)
OUT_TARGET_BLOCKS = 2          # buffer output (latensi vs aman dari xrun)

SPEAKER_DISTANCE = 1.5         # meter, jarak 11 speaker virtual dari kepala
RENDERING = "HRTFHQ"           # HRTFHQ | HRTF | SphericalHead | EqualPowerPanning
REVERB_BLEND = 0.0             # 0 = kering (studio). 0.1-0.3 = ada nuansa ruang
INPUT_GAIN = 1.0
MASTER_GAIN = 1.0
LFE_GAIN = 0.7
LIMITER_THRESHOLD_DB = -1.0
LIMITER_RELEASE_MS = 120.0

# ============================================================ layout 7.1.4 (urutan = Soidyn Driver / Atmos)
# L R C LFE Ls Rs Lrs Rrs Ltf Rtf Ltr Rtr  -> (azimuth derajat, + = kiri ; elevasi derajat)
LAYOUT = [(30, 0), (-30, 0), (0, 0), (0, 0), (90, 0), (-90, 0), (150, 0), (-150, 0),
          (45, 45), (-45, 45), (135, 45), (-135, 45)]
LFE_INDEX = 3
PLAYER_IDX = [i for i in range(12) if i != LFE_INDEX]


def az_el_to_xyz(az_deg, el_deg, d):
    """AVAudio3DPoint: +x kanan, +y atas, +z ke belakang (pendengar menghadap -z)."""
    az, el = np.radians(az_deg), np.radians(el_deg)
    return (float(-np.sin(az) * np.cos(el) * d), float(np.sin(el) * d), float(-np.cos(az) * np.cos(el) * d))


# ============================================================ upmixer (numpy)
try:
    from scipy.signal import lfilter
except Exception:  # scipy opsional
    lfilter = None


class Upmixer:
    """Input (n, ch) -> (12, n) urutan 7.1.4. Tinggi/surround diturunkan dari sinyal samping."""

    def __init__(self):
        self.hist = np.zeros(int(SAMPLE_RATE * 0.03), np.float32)
        a = float(np.exp(-2 * np.pi * 250.0 / SAMPLE_RATE))
        self.hp_b, self.hp_a, self.hp_z = np.array([a, -a]), np.array([1.0, -a]), np.zeros(1)

    def _hp(self, x):
        if lfilter is None:
            return x
        y, self.hp_z = lfilter(self.hp_b, self.hp_a, x, zi=self.hp_z)
        return y.astype(np.float32)

    def process(self, x):
        if INPUT_CHANNEL_MAP:
            x = x[:, INPUT_CHANNEL_MAP]
        n, ch = x.shape
        out = np.zeros((12, n), np.float32)
        if ch >= 12:                       # sudah 7.1.4
            out[:] = x[:, :12].T
            return out
        L = x[:, 0]
        R = x[:, 1] if ch > 1 else L
        if ch == 2 or ch == 1:             # stereo -> 7.1.4
            M, S = 0.5 * (L + R), 0.5 * (L - R)
            out[0], out[1], out[2] = L - 0.2 * M, R - 0.2 * M, 0.35 * M
        else:                              # 5.1 / 7.1 bed
            Ls, Rs = x[:, 4], x[:, 5]
            Lrs = x[:, 6] if ch >= 8 else np.zeros(n, np.float32)
            Rrs = x[:, 7] if ch >= 8 else np.zeros(n, np.float32)
            out[0], out[1], out[2], out[3] = L, R, x[:, 2], x[:, 3]
            out[4], out[5], out[6], out[7] = Ls, Rs, Lrs, Rrs
            S = 0.5 * ((L + Ls + Lrs) - (R + Rs + Rrs))
        S = self._hp(S.astype(np.float32))
        full = np.concatenate((self.hist, S))
        base = len(self.hist)

        def dl(ms):
            d = int(SAMPLE_RATE * ms / 1000.0)
            return full[base - d: base - d + n]

        if ch <= 2:                        # surround turunan hanya untuk stereo
            out[4], out[5] = 0.5 * dl(12), -0.5 * dl(12)
            out[6], out[7] = 0.35 * dl(22), -0.35 * dl(22)
        out[8], out[9] = 0.30 * dl(8), -0.30 * dl(8)      # tinggi depan
        out[10], out[11] = 0.25 * dl(18), -0.25 * dl(18)  # tinggi belakang
        self.hist = full[-len(self.hist):].copy()
        return out


# ============================================================ queue frame sederhana
class FrameQueue:
    def __init__(self, ch, max_frames):
        self.ch, self.max, self.q, self.n, self.lock = ch, max_frames, deque(), 0, threading.Lock()

    def push(self, a):
        with self.lock:
            self.q.append(a)
            self.n += len(a)
            while self.n > self.max:
                self.n -= len(self.q.popleft())

    def pop(self, k):
        with self.lock:
            if self.n < k:
                return None
            parts, need = [], k
            while need:
                c = self.q.popleft()
                if len(c) > need:
                    self.q.appendleft(c[need:])
                    c = c[:need]
                parts.append(c)
                need -= len(c)
            self.n -= k
        return parts[0] if len(parts) == 1 else np.concatenate(parts)


def stretch(y, m):
    """(2, n) -> (2, m) linear interpolation, untuk koreksi drift clock +-1 sampel per blok."""
    n = y.shape[1]
    pos, grid = np.linspace(0, n - 1, m), np.arange(n)
    return np.stack([np.interp(pos, grid, y[c]) for c in range(y.shape[0])]).astype(np.float32)


# ============================================================ Apple AV spatializer
class AVSpatial:
    def __init__(self):
        import objc
        import AVFoundation as AV
        self.objc, self.AV = objc, AV
        g = lambda name, default: getattr(AV, name, default)
        alg = {"HRTFHQ": g("AVAudio3DMixingRenderingAlgorithmHRTFHQ", 6),
               "HRTF": g("AVAudio3DMixingRenderingAlgorithmHRTF", 2),
               "SphericalHead": g("AVAudio3DMixingRenderingAlgorithmSphericalHead", 1),
               "EqualPowerPanning": g("AVAudio3DMixingRenderingAlgorithmEqualPowerPanning", 0)}[RENDERING]
        self.success = g("AVAudioEngineManualRenderingStatusSuccess", 0)

        fmt = AV.AVAudioFormat.alloc()
        self.mono = fmt.initStandardFormatWithSampleRate_channels_(float(SAMPLE_RATE), 1)
        self.stereo = AV.AVAudioFormat.alloc().initStandardFormatWithSampleRate_channels_(float(SAMPLE_RATE), 2)

        self.engine = AV.AVAudioEngine.alloc().init()
        self.env = AV.AVAudioEnvironmentNode.alloc().init()
        self.env.setOutputType_(g("AVAudioEnvironmentOutputTypeHeadphones", 1))
        dp = self.env.distanceAttenuationParameters()
        dp.setDistanceAttenuationModel_(g("AVAudioEnvironmentDistanceAttenuationModelInverse", 2))
        dp.setReferenceDistance_(float(SPEAKER_DISTANCE))
        dp.setMaximumDistance_(100.0)
        dp.setRolloffFactor_(1.0)
        rp = self.env.reverbParameters()
        rp.setEnable_(REVERB_BLEND > 0)
        if REVERB_BLEND > 0:
            rp.loadFactoryReverbPreset_(g("AVAudioUnitReverbPresetSmallRoom", 0))

        self.engine.attachNode_(self.env)
        self.engine.connect_to_format_(self.env, self.engine.mainMixerNode(), self.stereo)
        self.players = []
        for idx in PLAYER_IDX:
            p = AV.AVAudioPlayerNode.alloc().init()
            self.engine.attachNode_(p)
            self.engine.connect_to_format_(p, self.env, self.mono)
            p.setSourceMode_(g("AVAudio3DMixingSourceModeSpatializeIfMono", 0))
            p.setRenderingAlgorithm_(alg)
            p.setReverbBlend_(float(REVERB_BLEND))
            x, y, z = az_el_to_xyz(*LAYOUT[idx], SPEAKER_DISTANCE)
            p.setPosition_(AV.AVAudio3DPointMake(x, y, z))
            self.players.append(p)

        ok, err = self.engine.enableManualRenderingMode_format_maximumFrameCount_error_(
            g("AVAudioEngineManualRenderingModeOffline", 0), self.stereo, BLOCK, None)
        if not ok:
            raise RuntimeError("manual rendering gagal: %s" % err)
        ok, err = self.engine.startAndReturnError_(None)
        if not ok:
            raise RuntimeError("engine gagal start: %s" % err)
        for p in self.players:
            p.play()
        self.outbuf = AV.AVAudioPCMBuffer.alloc().initWithPCMFormat_frameCapacity_(self.stereo, BLOCK)

    @staticmethod
    def _chan(buf, c, n):
        return np.frombuffer(buf.floatChannelData()[c].as_buffer(n), dtype=np.float32, count=n)

    def selftest(self):
        """Pastikan buffer AV bisa ditulis/dibaca dari numpy."""
        buf = self.AV.AVAudioPCMBuffer.alloc().initWithPCMFormat_frameCapacity_(self.mono, 64)
        buf.setFrameLength_(64)
        v = self._chan(buf, 0, 64)
        v[:] = np.arange(64, dtype=np.float32)
        if not np.allclose(self._chan(buf, 0, 64), np.arange(64)):
            raise RuntimeError("buffer AV tidak bisa ditulis dari numpy (cek versi pyobjc)")

    def render(self, feeds):
        """feeds (11, BLOCK) float32 -> (2, BLOCK) float32 binaural."""
        AV = self.AV
        with self.objc.autorelease_pool():
            for p, row in zip(self.players, feeds):
                buf = AV.AVAudioPCMBuffer.alloc().initWithPCMFormat_frameCapacity_(self.mono, BLOCK)
                buf.setFrameLength_(BLOCK)
                self._chan(buf, 0, BLOCK)[:] = row
                p.scheduleBuffer_completionHandler_(buf, None)
            status, err = self.engine.renderOffline_toBuffer_error_(BLOCK, self.outbuf, None)
            if status != self.success:
                raise RuntimeError("renderOffline status=%s err=%s" % (status, err))
            n = int(self.outbuf.frameLength())
            out = np.zeros((2, BLOCK), np.float32)
            n = min(n, BLOCK)
            out[0, :n] = self._chan(self.outbuf, 0, n)
            out[1, :n] = self._chan(self.outbuf, 1, n)
        return out

    def stop(self):
        try:
            for p in self.players:
                p.stop()
            self.engine.stop()
        except Exception:
            pass


# ============================================================ limiter
try:
    from pedalboard import Limiter, Pedalboard
    _board = Pedalboard([Limiter(threshold_db=LIMITER_THRESHOLD_DB, release_ms=LIMITER_RELEASE_MS)])

    def limit(y):
        return np.clip(_board(y, SAMPLE_RATE, reset=False), -0.999, 0.999)
except Exception:
    def limit(y):  # fallback tanpa pedalboard
        return np.tanh(y).astype(np.float32)


# ============================================================ device & main
def find_devices():
    devs = sd.query_devices()
    in_idx = next((i for i, d in enumerate(devs)
                   if INPUT_DEVICE_NAME.lower() in d["name"].lower() and d["max_input_channels"] > 0), None)
    out_idx = None
    for cand in OUTPUT_DEVICE_CANDIDATES:
        for i, d in enumerate(devs):
            if (cand.lower() in d["name"].lower() and d["max_output_channels"] >= 2
                    and INPUT_DEVICE_NAME.lower() not in d["name"].lower()):
                out_idx = i
                break
        if out_idx is not None:
            break
    return devs, in_idx, out_idx


def main():
    devs, in_idx, out_idx = find_devices()
    if in_idx is None:
        sys.exit("Device '%s' tidak ditemukan. Daftar device:\n%s" % (INPUT_DEVICE_NAME, sd.query_devices()))
    if out_idx is None:
        sys.exit("Built-In Output tidak ketemu. Tambahkan namanya ke OUTPUT_DEVICE_CANDIDATES:\n%s" % sd.query_devices())
    n_in = INPUT_CHANNELS or min(12, devs[in_idx]["max_input_channels"])
    print("in : [%d] %s (%d ch)\nout: [%d] %s" % (in_idx, devs[in_idx]["name"], n_in, out_idx, devs[out_idx]["name"]))

    inq = FrameQueue(n_in, SAMPLE_RATE)
    outq = FrameQueue(2, SAMPLE_RATE)
    target = OUT_TARGET_BLOCKS * BLOCK
    state = {"primed": False, "under": 0, "run": True, "err": None, "ready": threading.Event()}
    upmix = Upmixer()

    def worker():
        try:
            av = AVSpatial()
            av.selftest()
        except Exception as e:  # noqa
            state["err"] = e
            state["ready"].set()
            return
        state["ready"].set()
        silence = np.zeros((2, BLOCK), np.float32)
        try:
            while state["run"]:
                while inq.n > 4 * BLOCK:           # buang backlog supaya latensi tidak menumpuk
                    inq.pop(BLOCK)
                x = inq.pop(BLOCK)
                if x is None:
                    time.sleep(0.0015)
                    continue
                bed = upmix.process(x * INPUT_GAIN)
                spat = av.render(np.ascontiguousarray(bed[PLAYER_IDX]))
                y = (spat + (bed[LFE_INDEX] * LFE_GAIN)[None, :]) * MASTER_GAIN
                y = limit(np.ascontiguousarray(y, dtype=np.float32))
                lvl = outq.n                        # koreksi drift antar clock
                if lvl > target + int(1.5 * BLOCK):
                    y = stretch(y, BLOCK - 1)
                elif lvl < target - BLOCK // 2:
                    y = stretch(y, BLOCK + 1)
                outq.push(np.ascontiguousarray(y.T))
        except Exception as e:  # noqa
            state["err"] = e
            state["run"] = False
        finally:
            av.stop()

    def in_cb(indata, frames, t, status):
        inq.push(indata[:, :n_in].copy())

    def out_cb(outdata, frames, t, status):
        if not state["primed"]:
            if outq.n >= target:
                state["primed"] = True
            else:
                outdata.fill(0)
                return
        y = outq.pop(frames)
        if y is None:
            state["under"] += 1
            state["primed"] = False
            outdata.fill(0)
        else:
            outdata[:] = y

    th = threading.Thread(target=worker, daemon=True)
    th.start()
    state["ready"].wait()
    if state["err"]:
        sys.exit("AV engine gagal: %r\n(pip3 install pyobjc-framework-AVFoundation ; macOS 10.15+)" % (state["err"],))

    with sd.InputStream(device=in_idx, channels=n_in, samplerate=SAMPLE_RATE, blocksize=PA_BLOCK,
                        dtype="float32", latency="low", callback=in_cb), \
         sd.OutputStream(device=out_idx, channels=2, samplerate=SAMPLE_RATE, blocksize=PA_BLOCK,
                         dtype="float32", latency="low", callback=out_cb):
        print("jalan (Ctrl+C untuk berhenti). Set output macOS ke '%s'." % INPUT_DEVICE_NAME)
        try:
            while state["run"]:
                time.sleep(2)
                print("\rin=%5d out=%5d underrun=%d   " % (inq.n, outq.n, state["under"]), end="", flush=True)
        except KeyboardInterrupt:
            pass
    state["run"] = False
    th.join(timeout=2)
    if state["err"]:
        print("\nerror: %r" % (state["err"],))


if __name__ == "__main__":
    main()